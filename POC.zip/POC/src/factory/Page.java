package factory;

public abstract class Page {

}
