/**
 * 
 */
package backtracking;

/**
 * @author 212720190
 * @date Jan 26, 2020
 */
public class KnightTourInChess {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
