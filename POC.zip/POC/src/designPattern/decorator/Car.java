/**
 * 
 */
package designPattern.decorator;

/**
 * @author 212720190
 * @date Dec 15, 2019
 */
public interface Car {

	public int distance(int mileage,int oil);
}
