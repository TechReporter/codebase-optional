/**
 * 
 */
package designPattern.decorator;

/**
 * @author 212720190
 * @date Dec 15, 2019
 */
public class HatchBack {
	
	public static int hundaiSports(int d) {
		return d*10;
	}
	
	public static int hundaiAsta(int d) {
		return d*5;
	}
	
	public static int hondaBrio(int d) {
		return d*3;
	}

}
