/**
 * 
 */
package designPattern.observer;

/**
 * @author 212720190
 * @date Dec 15, 2019
 */
public interface ObserverListener {
	void onEvent(Object event);

}
