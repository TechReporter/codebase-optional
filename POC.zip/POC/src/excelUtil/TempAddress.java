/**
 * 
 */
package excelUtil;

/**
 * @author 212720190
 * @date Mar 30, 2019
 */
public class TempAddress {

	private String flat;
	private String road;
	
	public TempAddress(String flat, String road) {
		super();
		this.flat = flat;
		this.road = road;
	}
	
	public String getFlat() {
		return flat;
	}
	public void setFlat(String flat) {
		this.flat = flat;
	}
	public String getRoad() {
		return road;
	}
	public void setRoad(String road) {
		this.road = road;
	}
	
	
	
}
