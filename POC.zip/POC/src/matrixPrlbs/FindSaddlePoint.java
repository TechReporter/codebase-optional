/**
 * 
 */
package matrixPrlbs;

/**
 * @author 212720190
 * @date Dec 16, 2019
 */
//find saddle point. saddle point is largest in column or smallest in row, vice versa  
public class FindSaddlePoint {


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
