/**
 * 
 */
package datastructure;

/**
 * @author 212720190
 * @date Apr 6, 2019
 */
public class ResourceLock {
	public volatile int flag = 1;
	static int val = 1;

}
