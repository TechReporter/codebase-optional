/**
 * 
 */
package datastructure;

/**
 * @author 212720190
 * @date Jan 21, 2020
 */
public class PairSumCloseToX {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
