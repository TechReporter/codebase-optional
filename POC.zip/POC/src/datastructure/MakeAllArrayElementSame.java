/**
 * 
 */
package datastructure;

/**
 * @author 212720190
 * @date May 26, 2019
 */
public class MakeAllArrayElementSame {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// to make all array element same, all element should multiply through LCM

	}

}
