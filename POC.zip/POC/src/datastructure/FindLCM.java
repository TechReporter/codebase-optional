/**
 * 
 *//*
package datastructure;

*//**
 * @author 212720190
 * @date May 26, 2019
 *//*
public class FindLCM {
	static int count=1;
	public static void main(String[] args) {

		int[] arr = {6,1,4,6,3,2,7,4};
		int k=3,L=2;
		int temp = Integer.MIN_VALUE;
		for(int i = 0;i<arr.length-L-1;i++) {
			int sum = 0;
			int ii=0;
			while(ii<k) {
				sum+=arr[i+ii];
				ii++;
			}
			for(int j=i+3;j<arr.length;j++) {
				int kk=0;a	
				while(kk<L) {
					sum+=arr[j+kk];
					kk++;
				}
			}
			if
		}

	}

}
*/