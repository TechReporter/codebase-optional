/**
 * 
 */
package Arraypractice;

/**
 * @author 212720190
 * @date Jan 22, 2020
 */
public class FindPickElement {


	public static void main(String[] args) {
		int[] arr = {2,};
	}

}
