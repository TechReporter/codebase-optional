/**
 * 
 */
package Arraypractice;

/**
 * @author 212720190
 * @date Feb 28, 2020
 */
public class PostOrderIterative {


	//postorder iteartive using two stack. push root in s1. while s1 not empty pop and push to s2.
	//push root left, root right in s1
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
