/**
 * 
 */
package Arraypractice;

/**
 * @author 212720190
 * @date Feb 5, 2020
 */
public class SearchElemAlmstSortArray {

	//search elemnt in almost sort array, where almosts sort
	// means a[i] either moved to a[i-1] or a[i+1]
	public static void main(String[] args) {
	}
}
