/**
 * 
 */
package Arraypractice;

/**
 * @author 212720190
 * @date Mar 1, 2020
 */
public class NoOfCoins {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
