package Arraypractice;

/**
 * @author 212720190
 * @date Feb 27, 2020
 */
public class DiagonalHeavyMatrix {

	//matrix will be diagonally heavy if a[i][i]>any other element of that row
	public static void main(String[] args) {
		int[][] mat = {{0, 1, 1, 0},  
				{1, 1, 0, 1},  
				{0, 1, 1, 1}, 
				{1, 1, 1, 1}};

		
	}

}
