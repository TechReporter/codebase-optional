/**
 * 
 */
package Arraypractice;

/**
 * @author 212720190
 * @date Jan 22, 2020
 */
public class SortBinaryArray {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
