/**
 * 
 */
package com;


public class commonUtil {
static int counter = 0;

	static int getVal() {
		counter++;
		return counter;
	}
	
}
