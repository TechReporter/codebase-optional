/**
 * 
 *//*
package com;

*//**
 * @author 212720190
 * @date Mar 7, 2019
 *//*
public class SortedAndRotatedArray {

	public static void main(String[] args) {

		int[] arr = {4,5,2,1,9,6};
		int size = arr.length;
	}

	static boolean checkSortedAndRotated(int[] arr, int n) {
		
		for(int ) {
			
		}
	}
}
*/