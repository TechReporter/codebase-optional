/**
 * 
 */
package com;

/**
 * @author 212720190
 * @date Apr 24, 2019
 */
public class CheckMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
