/**
 * 
 */
package javaMisc;

/**
 * @author 212720190
 * @date Nov 30, 2019
 */
public class MainClass {

	public static void main(String[] args) {
		new OuterClass().new innerClass().test1();
	}

}
