package javaMisc;

/**
 * @author 212720190
 * @date Nov 30, 2019
 */
public class OuterClass {
	
	private int x = 10;

	class innerClass {
		 public void test1() {
			System.out.println(x);
		}
	}

}
