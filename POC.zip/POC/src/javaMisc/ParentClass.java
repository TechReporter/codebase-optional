/**
 * 
 */
package javaMisc;

/**
 * @author 212720190
 * @date Dec 5, 2019
 */
public class ParentClass {

	public void ma() {
		System.out.println("test");
	}
}
