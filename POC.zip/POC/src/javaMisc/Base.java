package javaMisc;

/**
 * @author 212720190
 * @date Feb 1, 2020
 */
public class Base {
	protected int x;
	
	protected Base(int x) {
		this.x = x;
	}	
}
