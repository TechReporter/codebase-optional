package javaMisc;

/**
 * @author 212720190
 * @date Feb 4, 2020
 */
public class DiamondWithName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
