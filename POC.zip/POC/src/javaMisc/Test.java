/**
 * 
 */
package javaMisc;

import java.util.Arrays;

/**
 * @author 212720190
 * @date Feb 11, 2020
 */
public class Test {

	public static void main(String[] args) {

		Object aa = null;
		aa = "tanmoy";
		System.out.println(aa);
		aa = Arrays.asList(1,2,3);
		System.out.println(aa);
	}

}
