/**
 * 
 */
package leetcode;

/**
 * @author 212720190
 * @date Apr 14, 2020
 */
public class ContigiousSubarrayEqual01 {


	public static void main(String[] args) {/*
		int[] arr = {0,0,1,0,0,0,1,1};
		int zeroCount=0;
		int oneCount=0;
		int max=Integer.MIN_VALUE;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]==0)
				zeroCount++;
			else
				oneCount++;
			if(zeroCount==oneCount) {
				max=Math.max(max, zeroCount+oneCount);
			}
		}
		System.out.println(max);

	*/}

}
