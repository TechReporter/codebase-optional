/**
 * 
 */
package leetcode;

/**
 * @author 212720190
 * @date Mar 11, 2020
 */
public class strStrImpl {

	//28. Return the index of the first occurrence of needle in haystack, 
	//or -1 if needle is not part of haystack
	public static void main(String[] args) {
		String str = "hello";
			String ndl = "";
			System.out.println(str.indexOf(ndl));

	}

}
