/**
 * 
 */
package comparelist;

/**
 * @author 212720190
 * @date Jun 2, 2019
 */
public class Xclass {
	static String i = "X1";
	static String j = "X2";
	
	static {
		System.out.println("Yclass static i"+YClass.i+"Mani");
		System.out.println("Yclass static j"+YClass.j+"Mani");

	}

}
