/**
 * 
 */
package comparelist;

/**
 * @author 212720190
 * @date Jun 2, 2019
 */
public class YClass {
	static String i = "Y1";
	static String j = "Y2";
	
	static {
		System.out.println("xclass static i"+Xclass.i+"Mani");
		System.out.println("xclass static j"+Xclass.j+"mANI");

	}
}
