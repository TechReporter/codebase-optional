/**
 * 
 */
package comparelist;

/**
 * @author 212720190
 * @date Jun 2, 2019
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(new Xclass().j);
		System.out.println(new Xclass());
		System.out.println(new YClass());
		System.out.println(new YClass().i);

	}

}
