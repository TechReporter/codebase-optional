package com.hexad.model;

public final class ParkingLotConstants {

	public static final String FILEPATH = "src/com/hexad/model/parking_lot.txt";
	
	public static final String PARKING_FULL_MESSAGE = "Sorry, parking lot is full";
	public static final String CAR_NOT_AVAILABLE_MESSAGE = "Not Found";

}
