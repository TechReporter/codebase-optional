package main.java.com.conference.management.exceptions;

/**
 * Created by girmes on 22/05/17.
 */
public class UnsupportedSourceException extends Throwable {

    public UnsupportedSourceException(String message) {
        super(message);
    }
}
