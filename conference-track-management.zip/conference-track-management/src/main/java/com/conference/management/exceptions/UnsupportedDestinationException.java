package main.java.com.conference.management.exceptions;

/**
 * Created by girmes on 22/05/17.
 */
public class UnsupportedDestinationException extends Throwable {

    public UnsupportedDestinationException(String message) {
        super(message);
    }

}
