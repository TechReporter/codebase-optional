package main.java.com.conference.management.enums;

/**
 * Created by girmes on 22/05/17.
 */
public enum  DataSourceEnum {

    FILE;
}
